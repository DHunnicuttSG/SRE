Grep Practice Dataset
=====================

Files:
- log.txt: mixed INFO/DEBUG/ERROR log lines.
- system.log: mixed casing of warning/success/error.
- output.txt: lines including the word success in various cases.
- report.txt: includes 'failed' variants.
- projects/: Python files with TODOs across subdirs.
- animals.txt: words where 'cat' appears inside other words.
- app.log: contains DEBUG you may want to exclude.
- server.log: lines starting with ERROR and others.
- kernel.log: contains 'critical' with different cases.
- access.log: IPv4 addresses.
- data.txt: dates in YYYY-MM-DD and others.
- etc/: configuration files with different ports.
- notes.txt: extra lines mentioning 'critical'.

Suggested exercises are in your chat—run them against these files.
