# TODO: refactor initialization
print("Hello")
# todo: add logging
