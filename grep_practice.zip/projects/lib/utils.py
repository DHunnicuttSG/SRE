# Utility functions
# TODO: write unit tests for parse_config
